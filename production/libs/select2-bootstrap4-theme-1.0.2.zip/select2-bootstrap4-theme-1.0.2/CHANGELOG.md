# Changelog
All notable changes to this project will be documented in this file.

## 1.0.1 - 2018-02-15

- Fixed some bugs when running `npm run dev`;

## 1.0.0 - 2017-12-12

- Create project